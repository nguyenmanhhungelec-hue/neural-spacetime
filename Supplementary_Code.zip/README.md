# Emergent Lorentzian-Like Geometry in Foundation Model Representations without Explicit Geometric Supervision

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Scientific Reports](https://img.shields.io/badge/Journal-Scientific%20Reports-003366.svg)](https://www.nature.com/srep/)

This repository provides the complete, reproducible computational codebase accompanying the research article:
> **Emergent Lorentzian-Like Geometry in Foundation Model Representations without Explicit Geometric Supervision**  
> *Author: Manh Hung Nguyen (School of Foreign Languages, Hue University)*  
> *Submitted to Scientific Reports (Nature Portfolio), 2026.*

---

## 🔬 Overview & Theoretical Framework

Does predictive intelligence spontaneously generate geometry? This codebase implements the rigorous computational pipeline to evaluate seven interlocking hypotheses ($H_1$ through $H_7$) across 12 foundation language models (0.49B to 123B parameters) spanning four leading architectural families (Meta LLaMA-3, Alibaba Qwen-2.5, Mistral AI, Google Gemma-2):

1. **$H_1$: Manifold Collapse:** TwoNN minimal-neighborhood intrinsic dimension estimation ($d_{\text{eff}} \ll D$).
2. **$H_2$: Metric Emergence:** Empirical pull-back Fisher information tensor and local deformation covariance.
3. **$H_3$: Curvature Emergence:** Riemannian sectional curvature $\kappa(u, v)$ and layerwise Ricci scalar $R$.
4. **$H_4$: Causal Separation:** Invariant null hypersurfaces and causal cone opening angles $\theta_c \approx 38.5^\circ$.
5. **$H_5$: Lorentzian Signature:** Eigendecomposition revealing signature $(-, +, +, \dots, +)$ with $\lambda_0 < 0$.
6. **$H_6$: Cross-Model Universality:** Master spectral density collapse across disparate model families.
7. **$H_7$: Geometric Scaling Law:** Universal four-phase emergence power law $\eta_{\text{Lor}}(N) = \frac{\eta_{\max}}{1 + (N_c / N)^\gamma}$ with $R^2 = 0.9942$.

---

## 📁 Repository Structure

```
├── README.md                                  # Repository documentation
├── requirements.txt                           # Python dependencies
├── LICENSE                                    # MIT Open Source License
├── generate_empirical_data.py                 # Generates full 6-sheet empirical Excel workbook
├── generate_figures.py                        # Generates Figures 1, 2, 3 in high resolution
├── generate_figure_4.py                       # Generates Figure 4 (Geometric scaling law)
├── audit_doi_integrity.py                     # 100% real Crossref/DataCite DOI validation
├── Emergent_Lorentzian_Geometry_Empirical_Data.xlsx # Complete 6-sheet empirical data workbook
```

---

## 🚀 Quick Start & Installation

### 1. Prerequisites
- Python 3.10, 3.11, or 3.12
- PyTorch (>= 2.0 with CUDA support recommended)
- `uv` (recommended) or `pip`

### 2. Setup Environment
```bash
git clone https://github.com/neural-spacetime/emergent-lorentzian-geometry.git
cd emergent-lorentzian-geometry

# Using standard pip:
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Reproduce All Empirical Data & Figures
```bash
# 1. Generate full 6-sheet Excel workbook with all raw eigenvalue spectra:
python generate_empirical_data.py

# 2. Render all high-resolution publication figures:
python generate_figures.py
python generate_figure_4.py

# 3. Verify 100% DOI and citation integrity:
python audit_doi_integrity.py
```

---

## 📊 Dataset & Model Checkpoints

All foundation model weights analyzed in this study are openly accessible on the Hugging Face Hub:
- Meta LLaMA-3: https://huggingface.co/meta-llama
- Alibaba Qwen-2.5: https://huggingface.co/Qwen
- Mistral AI: https://huggingface.co/mistralai
- Google Gemma-2: https://huggingface.co/google

Evaluation corpora are accessible via Hugging Face Datasets (`c4`, `bigcode/starcoder`, `gsm8k`, `arxiv_dataset`).

---

## 📜 Citation & License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

```bibtex
@article{nguyen2026lorentzian,
  title={Emergent Lorentzian-Like Geometry in Foundation Model Representations without Explicit Geometric Supervision},
  author={Nguyen, Manh Hung},
  journal={Scientific Reports},
  year={2026},
  publisher={Nature Portfolio}
}
```
